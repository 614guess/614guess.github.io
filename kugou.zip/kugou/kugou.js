window.onload = function () {
    // 轮播需要的图片路径
    const imgArr = [
        './image/20220317145017775531.jpg',
        './image/20220808200409391874.jpg',
        './image/20220808200526788597.jpg',
        './image/20221012151627352369.jpg',
        './image/20230107190004462776.jpg',
        './image/20220317144937978098.jpg'
    ]
    //  图片数量，渲染图片时使用
    const count = imgArr.length;
    //  轮播对象
    const banner = document.querySelector(".banner");
    //  左右按钮对象
    const leftbtn = document.querySelector("#left");
    const rightbtn = document.querySelector("#right");
    //  白点对象数组
    const dots = document.querySelectorAll(".banner>.box>ul>li");
    //  这个变量用于控制要使用第几张轮播图片，从10000 * count + 1开始是为了防止他减为负数，+1是为了有更好的连贯性
    let n = 10000 * count + 1;
    //  开启轮播，并接收其返回值（用于停止轮播）
    let s = bannerActive();
    //  遍历白点数组，绑定移入移出事件
    for (let i = 0; i < dots.length; i++) {
        //  移入白点时，将轮播停止，根据索引渲染对应的背景图，再渲染白点
        dots[i].addEventListener("mouseover", () => {
            clearInterval(s);
            bannerFun(i);
            n = 10000 * count + i;
            renderDot();
        });
        //  移出白点时，开启轮播，更新返回值
        dots[i].addEventListener("mouseout", () => {
            s = bannerActive();
        });
    }
    //  用于渲染点的函数，根据n将对应的点添加悬停样式，将其他点移出悬停样式
    function renderDot() {
        for (let i = 0; i < dots.length; i++) {
            dots[i].classList.remove("classHover");
            if (i == Math.abs(n) % count) {
                dots[i].classList.add("classHover");
                // console.log(n)
            }
        }
    }
    //  给左右按钮添加点击事件
    leftbtn.addEventListener("click", () => {
        bannerFun(--n);
        renderDot();
    });
    rightbtn.addEventListener("click", () => {
        bannerFun(++n);
        renderDot();
    });
    //  轮播函数，先渲染点，再渲染背景图片
    function bannerActive() {
        const s = setInterval(() => {
            renderDot();
            bannerFun(n++);
        }, 1600);
        return s;
    }
    //  渲染背景
    function bannerFun(num) {
        banner.style.backgroundImage = `url(${imgArr[Math.abs(num) % count]})`;
    }

    // 返回顶部

    const retop = document.querySelector("#returntop");
    retop.addEventListener("click", () => {
        // console.log(document.body.scrollTop)
        // document.documentElement.scrollTop = 0;
        const s = setInterval(() => {
            if (document.documentElement.scrollTop > 0) {
                document.documentElement.scrollTop -= 100;
            } else {
                clearInterval(s);
            }
        }, 10);
    });


    // 悬浮框

    const xf = document.querySelector(".xuanfu");
    // console.log(xf);
    window.onscroll = function () {
        if (document.documentElement.scrollTop > 400) {
            xf.style.position = "fixed";
            xf.style.top = "280px";
        } else {
            xf.style.position = "absolute";
            xf.style.top = "760px";
        }
    }


    // 列表随机切换

    const head1 = document.querySelector(".content2>.left>.title>.left>ul");
    const head2 = document.querySelector(".content3>.title>.left>ul");
    const head3 = document.querySelector(".content5>.title>.left>ul")
    const body1 = document.querySelector(".content2>.left>.main>ul");
    const body2 = document.querySelector(".content3>.main>ul");
    const body3 = document.querySelector(".content5>.main");

    // console.log(head1, head2, body1, body2);
    // console.log(head3, body3);

    headHover(head1, body1);
    headHover(head2, body2);
    headHover(head3, body3);

    //  添加鼠标移入事件
    function headHover(head, body) {
        for (let i = 0; i < head.children.length; i++) {
            head.children[i].addEventListener("mouseover", () => {
                daluanLi(body);
                liHover(head, i);
            });
        }
    }

    liHover(head1, 0);
    liHover(head2, 0);
    liHover(head3, 0);

    //  li悬停样式设置
    function liHover(head, n) {
        const boxArr = head.querySelectorAll(".box");
        const iArr = head.querySelectorAll("i");
        // console.log(iArr);
        // console.log(boxArr);
        for (let i = 0; i < boxArr.length; i++) {
            if (i === n) {
                boxArr[i].style.backgroundColor = "rgba(0, 169, 255, 0.1)";
                boxArr[i].style.color = "#00A9FF";
                if (iArr.length !== 0) {
                    iArr[i].style.visibility = "visible";
                }
            } else {
                boxArr[i].style.backgroundColor = "";
                boxArr[i].style.color = "";
                if (iArr.length !== 0) {
                    iArr[i].style.visibility = "";
                }
            }
        }
    }

    // 用于切换的图片
    const bodyImgArr = [
        "./image/20220810102002467144.jpg",
        "./image/20220531161239190.jpg",
        "./image/20220811230718348.jpg",
        "./image/20190919181636698177.jpg",
        "./image/20191115175338400312.jpg",
        "./image/20200819175118566928.jpg",
        "./image/20201207134716994336.jpg",
        "./image/20210630141101608539.jpg",
        "./image/20210702081927884718.jpg",
        "./image/20210813110609255220.jpg",
        "./image/20220510185901334740.jpg",
        "./image/20210903184704477802.jpg",
        "./image/20210912000735358694.jpg",
        "./image/20210914141726699353.jpg",
        "./image/20211103120537893541.jpg",
        "./image/20211208100152706123.jpg",
        "./image/20211228154343953202.jpg",
        "./image/20220128155845696533.jpg",
        "./image/20220128160906877436.jpg"
    ]
    //  打乱li
    function daluanLi(body) {
        const arr = Array.from(body.children);
        for (let i = 0; i < arr.length; i++) {
            const sj = parseInt(Math.random() * arr.length);
            const temp = arr[i];
            arr[i] = arr[sj];
            arr[sj] = temp;
            const imgNode = arr[i].querySelector(".image");
            imgNode.style.backgroundImage = `url(${bodyImgArr[parseInt(Math.random() * bodyImgArr.length)]})`;
        }
        body.innerHTML = "";
        arr.forEach((item) => body.appendChild(item));
    }


    //  登录
    const loginBox = document.querySelector(".loginBox");
    const closeBtn = document.querySelector(".loginBox>.box>.close>i");
    const loginBtn = document.querySelector(".head_right_login");

    // console.log(loginBox, closeBtn, loginBtn);
    // 关闭登录
    closeBtn.addEventListener("click", () => {
        loginBox.style.display = "none";
    });
    // 打开登录
    loginBtn.addEventListener("click", () => {
        loginBox.style.display = "flex";
    });


    //  二维码移动
    const maBox = document.querySelector(".loginBox>.box>.ma");
    const maImg = document.querySelector(".loginBox>.box>.ma>.img");
    const maImg1 = document.querySelector(".loginBox>.box>.ma>.img1");

    maBox.addEventListener("mouseover", () => {
        maImg.style.left = "20px";
        maImg.style.transform = "translateX(0)";

        maImg1.style.transition = "all 0.3s linear 0.3s";
        maImg1.style.visibility = "inherit";
    });
    maBox.addEventListener("mouseout", () => {
        maImg1.style.transition = "all 0s linear";
        maImg1.style.visibility = "hidden";

        maImg.style.left = "50%";
        maImg.style.transform = "translateX(-50%)";
    });
}